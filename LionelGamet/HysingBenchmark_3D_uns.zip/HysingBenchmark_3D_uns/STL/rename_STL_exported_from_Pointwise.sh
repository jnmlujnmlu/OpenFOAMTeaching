# We rename STL files to their file name
for i in `\ls *.stl`
do
  j=`echo $i | sed -e 's#\.stl##'`
  cat $i | sed -e "s#exported_from_Pointwise#$j#g" > ${i}.new
  mv -f ${i}.new $i
done
