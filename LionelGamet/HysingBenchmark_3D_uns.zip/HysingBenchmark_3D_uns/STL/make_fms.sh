# Create the input fms file for cfMesh unstructured tools
cat backWall.stl \
    bottomWall.stl \
    frontWall.stl \
    leftWall.stl \
    rightWall.stl \
    topWall.stl > HysingSTL.stl
surfaceToFMS HysingSTL.stl
surfaceFeatureEdges -angle 60 HysingSTL.fms HysingSTL_withedges.fms
