# Create the input fms file for cfMesh unstructured tools
cat xMin.stl \
    yMin.stl \
    zMin.stl \
    xMax.stl \
    yMax.stl \
    zMax.stl > StationaryDroplet_3D.stl
surfaceToFMS StationaryDroplet_3D.stl
surfaceFeatureEdges -angle 60 StationaryDroplet_3D.fms StationaryDroplet_3D_withedges.fms
