#!/bin/sh

gedit system/blockMeshDict system/surfaceFeatureExtractDict system/snappyHexMeshDict system/meshQualityDict  foam.foam 
